import logo from './logo.svg';
import './App.css';
import Notes from './pages/Notes';

function App() {
  return (
    <div className="App">
      <Notes/>
    </div>
  );
}

export default App;
